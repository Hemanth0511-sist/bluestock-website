class FinancialMetrics:

    @staticmethod
    def safe_divide(numerator, denominator):
        """
        Safely divide two numbers.
        Returns None if values are invalid or denominator is zero.
        """
        if numerator is None or denominator is None:
            return None

        if denominator == 0:
            return None

        return numerator / denominator

    @staticmethod
    def revenue_growth(current, previous):
        """Perform the revenue growth operation."""
        if previous in (0, None):
            return None
        return round(((current - previous) / previous) * 100, 2)

    @staticmethod
    def profit_growth(current, previous):
        """Perform the profit growth operation."""
        if previous in (0, None):
            return None
        return round(((current - previous) / previous) * 100, 2)

    @staticmethod
    def debt_to_equity(total_debt, equity):
        """Perform the debt to equity operation."""
        result = FinancialMetrics.safe_divide(total_debt, equity)
        return None if result is None else round(result, 2)

    @staticmethod
    def roe(net_profit, equity):
        """Perform the roe operation."""
        result = FinancialMetrics.safe_divide(net_profit, equity)
        return None if result is None else round(result * 100, 2)

    @staticmethod
    def roce(ebit, capital_employed):
        """Perform the roce operation."""
        result = FinancialMetrics.safe_divide(ebit, capital_employed)
        return None if result is None else round(result * 100, 2)

    @staticmethod
    def return_on_assets(net_profit, total_assets):
        """Perform the return on assets operation."""
        result = FinancialMetrics.safe_divide(net_profit, total_assets)
        return None if result is None else round(result * 100, 2)

    @staticmethod
    def asset_turnover(revenue, total_assets):
        """Perform the asset turnover operation."""
        result = FinancialMetrics.safe_divide(revenue, total_assets)
        return None if result is None else round(result, 2)

    @staticmethod
    def net_profit_margin(net_profit, revenue):
        """Perform the net profit margin operation."""
        result = FinancialMetrics.safe_divide(net_profit, revenue)
        return None if result is None else round(result * 100, 2)

    @staticmethod
    def operating_profit_margin(operating_profit, revenue):
        """Perform the operating profit margin operation."""
        result = FinancialMetrics.safe_divide(operating_profit, revenue)
        return None if result is None else round(result * 100, 2)

    @staticmethod
    def interest_coverage(ebit, interest_expense):
        """Perform the interest coverage operation."""
        result = FinancialMetrics.safe_divide(ebit, interest_expense)
        return None if result is None else round(result, 2)

    @staticmethod
    def current_ratio(current_assets, current_liabilities):
        """Perform the current ratio operation."""
        result = FinancialMetrics.safe_divide(current_assets, current_liabilities)
        return None if result is None else round(result, 2)

    @staticmethod
    def debt_ratio(total_debt, total_assets):
        """Perform the debt ratio operation."""
        result = FinancialMetrics.safe_divide(total_debt, total_assets)
        return None if result is None else round(result, 2)

    @staticmethod
    def net_debt(total_debt, cash):
        """Perform the net debt operation."""
        if total_debt is None:
            return None

        if cash is None:
            cash = 0

        return round(total_debt - cash, 2)

    @staticmethod
    def free_cash_flow(cfo, capex):
        """Perform the free cash flow operation."""
        if cfo is None or capex is None:
            return None

        return round(cfo + capex, 2)

    @staticmethod
    def cfo_quality_score(cfo, net_profit):
        """Perform the cfo quality score operation."""
        result = FinancialMetrics.safe_divide(cfo, net_profit)
        return None if result is None else round(result, 2)
    
    @staticmethod
    def cfo_quality(cfo, net_profit):
        """Perform the cfo quality operation."""
        return FinancialMetrics.cfo_quality_score(cfo, net_profit)

    @staticmethod
    def capex_intensity(capex, revenue):
        """Perform the capex intensity operation."""
        if capex is None or revenue in (0, None):
            return None

        result = FinancialMetrics.safe_divide(abs(capex), revenue)
        return None if result is None else round(result * 100, 2)

    @staticmethod
    def fcf_conversion(fcf, operating_profit):
        """Perform the fcf conversion operation."""
        result = FinancialMetrics.safe_divide(fcf, operating_profit)
        return None if result is None else round(result * 100, 2)

    @staticmethod
    def dividend_payout(dividend, net_profit):
        """Perform the dividend payout operation."""
        result = FinancialMetrics.safe_divide(dividend, net_profit)
        return None if result is None else round(result * 100, 2)

    @staticmethod
    def earnings_per_share(net_profit, shares_outstanding):
        """Perform the earnings per share operation."""
        result = FinancialMetrics.safe_divide(net_profit, shares_outstanding)
        return None if result is None else round(result, 2)

    @staticmethod
    def book_value_per_share(equity, shares):
        """Perform the book value per share operation."""
        result = FinancialMetrics.safe_divide(equity, shares)
        return None if result is None else round(result, 2)

    @staticmethod
    def price_to_book(price, book_value):
        """Perform the price to book operation."""
        result = FinancialMetrics.safe_divide(price, book_value)
        return None if result is None else round(result, 2)

    @staticmethod
    def price_to_earnings(price, eps):
        """Perform the price to earnings operation."""
        result = FinancialMetrics.safe_divide(price, eps)
        return None if result is None else round(result, 2)