# Performance Notes — Day 43

## API load test

Requirement: 10 concurrent screener API calls, all completing within 10 seconds.

Observed result:

- Concurrent requests: 10
- Total wall time: 0.1099 seconds
- Successful requests: 10
- Failed requests: 0
- Average response: 0.0860 seconds
- Fastest response: 0.0533 seconds
- Slowest response: 0.1055 seconds
- Status: PASS

## Company Profile dashboard performance

Requirement: five tickers, each profile load under 3 seconds.

Observed tickers: TCS, INFY, HCLTECH, BEL, HAL.

- TCS: 0.0512 seconds profile load
- INFY: 0.0507 seconds
- HCLTECH: 0.0498 seconds
- BEL: 0.0509 seconds
- HAL: 0.0470 seconds
- Average: 0.0499 seconds
- Slowest: 0.0512 seconds
- Status: PASS

## End-to-end integration

FastAPI and Streamlit were started simultaneously on:

- FastAPI: `127.0.0.1:8000`
- Streamlit: `127.0.0.1:8501`

Verified:

- API health: PASS
- API company endpoint: PASS — 92 records
- API screener: PASS — 52 results for the tested configuration
- Streamlit health: PASS
- Concurrent run: PASS
- Port 8000: PASS
- Port 8501: PASS
- No port conflict detected

## SQLite optimisation

The optimisation pass created/verified these indexes:

1. `idx_profitandloss_company_id_year`
2. `idx_balancesheet_company_id_year`
3. `idx_cashflow_company_id_year`
4. `idx_prosandcons_company_id`
5. `idx_sectors_company_id`
6. `idx_stock_prices_company_id`
7. `idx_market_cap_company_id_year`
8. `idx_financial_ratios_company_id`
9. `idx_historical_financial_ratios_company_id_year`
10. `idx_peer_groups_company_id`

SQLite `ANALYZE` was also run after index creation.

## Bottlenecks

No performance bottleneck was observed against the Day 43 acceptance targets. The tested API and dashboard paths were substantially below their response-time thresholds.
