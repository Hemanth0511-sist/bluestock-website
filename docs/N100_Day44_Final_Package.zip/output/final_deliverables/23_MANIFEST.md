# Final Deliverables Archive Manifest

This archive contains 23 project artifacts selected from the completed N100 project outputs. The project plan explicitly requires 23 deliverables to be archived under output/final_deliverables/.

| # | Archived artifact | Source |
|---:|---|---|
| 1 | `01_cluster_labels.csv` | project output |
| 2 | `02_elbow_plot.png` | project output |
| 3 | `03_correlation_heatmap.png` | project output |
| 4 | `04_outlier_report.csv` | project output |
| 5 | `05_portfolio_stats.csv` | project output |
| 6 | `06_openapi.json` | project output |
| 7 | `07_postman_collection.json` | project output |
| 8 | `08_pytest_report.html` | project output |
| 9 | `09_analyst_guide.pdf` | project output |
| 10 | `10_screener_output.xlsx` | project output |
| 11 | `11_pros_cons_generated.csv` | project output |
| 12 | `12_valuation_summary.xlsx` | project output |
| 13 | `13_valuation_flags.csv` | project output |
| 14 | `14_peer_comparison.xlsx` | project output |
| 15 | `15_cashflow_intelligence.xlsx` | project output |
| 16 | `16_capital_allocation_distribution.csv` | project output |
| 17 | `17_perf_notes.md` | project output |
| 18 | `18_README.md` | project output |
| 19 | `19_src_api.zip` | project output |
| 20 | `20_tearsheets.zip` | project output |
| 21 | `21_sector_reports.zip` | project output |
| 22 | `22_tests.zip` | project output |

Generated for Day 44 documentation and packaging. Verify the project-specific acceptance gates on Day 45 before sign-off.
